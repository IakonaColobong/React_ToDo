// import logo from './logo.svg';
import "./App.css";
import Navigation from "./Components/Navigation";
import Bootstrap from "./Components/Bootstrap/Bootstrap";
import Todo from "./Components/Todo/Todo";
import Categories from "./Components/Categories/Categories";
import Login from "./Components/Login/Login";
import NotFound from "./Components/NotFound";


import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      {/* <Router>
        <Routes>
        <Route path="/" element={<Login />} />
        <Route path="login" element={<Login />} />
        <Route path="todo" element={<Todo />} />
        <Route path="categories" element={<Categories />} />
        <Route path="bootstrap" element={<Bootstrap />} />
        <Route path="*" element={<NotFound />} />
        </Routes>
      </Router> */}
      <Bootstrap />
    </div>
  );
}
export default App;

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }
