import React from 'react';

export default function Bootstrap() {
  return (
  <section className='bootstrap'>
      <h1>Bootstrap</h1>
  </section>
    );
}
