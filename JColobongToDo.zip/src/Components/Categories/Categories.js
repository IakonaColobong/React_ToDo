import React from 'react';

export default function Categories() {
  return (
  <section className='categories'>
      <h1>Categories</h1>
  </section>
    );
}
