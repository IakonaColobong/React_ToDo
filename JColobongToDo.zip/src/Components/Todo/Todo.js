import React from 'react';

export default function Todo() {
  return (
      <section className='todo'>
          <h1>To Do List</h1>
      </section>
  )
}
